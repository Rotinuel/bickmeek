import adapter from '@sveltejs/adapter-vercel';

/** No `src` folder: routes, lib, hooks and the app template live at the project root. */
const config = {
	kit: {
		adapter: adapter(),
		files: {
			assets: 'static',
			hooks: {
				client: 'hooks.client',
				server: 'hooks.server',
				universal: 'hooks'
			},
			lib: 'lib',
			params: 'params',
			routes: 'routes',
			serviceWorker: 'service-worker',
			appTemplate: 'app.html',
			errorTemplate: 'error.html'
		},
		// SvelteKit already rejects cross-site form posts; keep it on.
		csrf: { checkOrigin: true }
	}
};

export default config;
